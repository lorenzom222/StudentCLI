Ruiyang Peng
rpeng3@u.rochester.edu
3/2/2023
HW4 Airplane
My program runs correctly and gives correct outputs. I used arrays to store information of each plane and then evaluated each contract separately.
I spent approximately 5 hours on this assignment. Some of the tricky parts was to get the scanner to start reading in a new line, how to write a correct loop that evaluates each contract for every plane.