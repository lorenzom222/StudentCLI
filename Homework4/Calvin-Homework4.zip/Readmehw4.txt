﻿Basics: Calvin(Jinghao) Fu,  jfu14@u.rochester.edu, March 7th Tuesday, Assignment 4
Self Review: 95% correctness. Not sure if the name I print is correct or not. It prints Lucy most of the time. Could you help me check if the second part around line 98 is correct or not? Thanks!
Total Estimate time: around 12 hours.




Program Description:


Firstly, I declare the instance variables and the constructor for the Airplane object.


Inside the main method, I ask for the user’s input for min, max, range, speed, hourly_cost, and fuel_rate, and store them in an array called airplanes.


Then, ask for <mass> <distance> <payment>
A for loop inside the while loop gets the formula for the final profits (Payments - Total Cost).  Pass the procedure to each airplane array and determine which one has the best profits and print the profits out. Otherwise, we print decline.


Once the user enters quit, we print out the total profits in two decimal places.