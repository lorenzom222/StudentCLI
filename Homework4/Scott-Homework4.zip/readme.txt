Name: Scott Sun
Email: ssun27@u.rochester.edu
The date of submission: Feb 27
The assignment number 4(Airplane)

My program works well. I will estimate 100% correctness on storing all the information of my fleet, giving the best profit of each contract and giving the total profit after a quit token. I believe overall works well.
I spent around four to five hours on this homework. I spend the most time on how to do the object array, and how to determine if to decline and give the total profit. It sometimes involves some logic problem. Therefore, it takes me much time to make sure I can get the best profit from each contract and decline all the non-profitable contracts. After I tried it many times, it works well now.